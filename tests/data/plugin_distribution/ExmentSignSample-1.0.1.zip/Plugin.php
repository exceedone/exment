<?php
namespace App\Plugins\ExmentSignSample;

use Exceedone\Exment\Services\Plugin\PluginPageBase;

class Plugin extends PluginPageBase
{
}
